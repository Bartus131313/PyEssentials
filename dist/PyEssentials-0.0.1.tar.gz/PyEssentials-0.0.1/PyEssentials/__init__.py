from PyEssentials.commands import CommandRegister, CommandBase
from PyEssentials.functions import generate_id, generate_custom_id, PrintError