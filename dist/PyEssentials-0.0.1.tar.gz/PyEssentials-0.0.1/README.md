# PyEssentials 
## by Bartek Kansy

### This package contains classes and functions that can be used to create programs, consoles etc.